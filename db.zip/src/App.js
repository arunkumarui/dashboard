import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Dashboard from './Component/pages/Dashboard';
import Wallet from './Component/pages/Wallet';
import Landing from "./Component/pages/Landing";
import Chart from "./Component/pages/Chart";


function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Landing />,
      children: [
        {
          index: true,
          element: <Dashboard />,
        },

        {
          path: "/Dashboard", 
          element: <Dashboard />
        },
        {
          path: "/Wallet", 
          element: <Wallet />
        },
        {
          path: "/Chart", 
          element: <Chart />
        },
      ],
    },
  ]);

  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
