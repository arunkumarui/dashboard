import React from 'react'
 import { HiOutlineMenuAlt2 } from 'react-icons/hi'
import { MdSpaceDashboard } from 'react-icons/md'
import { CiMail } from "react-icons/ci";
import { IoSettingsOutline } from "react-icons/io5";
import { IoNotificationsOutline } from "react-icons/io5";
import { IoIosContact } from "react-icons/io";

 



const Header = ({ togglesidebar }) => {
    return (
        <nav className='headersection fixed top-0 z-50 w-full bg-white border-gray-200 dark:bg-gray-800 dark:border-gray-700'>
            <div className='px-3 py-3 lg:px-5 lg:pl-3'>
                <div className='flex items-center justify-between'>
                    <div className='flex items-center justify-start rtl:justify-end'>
                        <button className='inline-flex items-center p-2 text-sm text-gray-500 rounded-lg sm:hidden  focus:outline-none
                        dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600 ' onClick={togglesidebar}>
                            <HiOutlineMenuAlt2 className="text-2xl" />
                        </button>
                        <MdSpaceDashboard className='h-8 me-10 text-2xl text-violet-500 d-none' />

                        {/* search bar here to start */}

                        <form className="max-w-md mx-auto">
                            <label htmlFor="default-search" className="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                                    <svg className="w-4 h-3 text-gray-500 dark:text-gray-400 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                                    </svg>
                                </div>
                                <input type="search" id="default-search" className="focus:ring-blue-500 border-none block dark:text-white w-full h-6 p-4 ps-10 text-sm dark:bg-gray-700 rounded-lg" placeholder="Search" required />
                            </div>
                        </form>

                        {/* search bar here to end */}

                    </div>

                    <div className='flex items-center gap-x-3'>
                        <CiMail className='self-center text-xl sm:text-1xl whitespace-nowrap dark:text-white text-white' />
                        <IoSettingsOutline className='self-center text-xl sm:text-1xl whitespace-nowrap dark:text-white text-white' />
                        <IoNotificationsOutline className='self-center text-xl sm:text-1xl whitespace-nowrap dark:text-white text-white' />
                        {/* <img src={profile} alt="profile image" /> */}
                        <IoIosContact className='self-center text-xl sm:text-2xl whitespace-nowrap dark:text-white text-white' />

                    </div>

                </div>
            </div>
        </nav>
    )
}

export default Header
