import React from 'react'

const Wallet = () => {
  return (
    <div className='flex flex-wrap mb-4 w-full ml-14 p-4 responsive-style h-full ' style={{ marginTop: '100px' }}>
      <h1 className='text-center w-full'>Wallet </h1>
    </div>
  )
}

export default Wallet