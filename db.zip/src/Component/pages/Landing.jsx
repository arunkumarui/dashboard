import React from 'react'
import { useState } from 'react';
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';
import { Outlet } from 'react-router-dom';

const Landing = () => {
  // darkmode start
  // const [darkMode, setDarkMode] = useState(false);

  // const toggleDarkMode = () => {
  //   setDarkMode(!darkMode);
  // };

  //sidebar here to start
  const [sidebaropen, setSidebar] = useState(false);
  const togglesidebar = () => {
    setSidebar(!sidebaropen)
  }
  return (
    <>
      <Header togglesidebar={togglesidebar} />
      <div class="flex flex-col">
        <div class="flex flex-1 overflow-hidden">
          <Sidebar sidebaropen={sidebaropen} />
        </div>
        <div class="flex-1 overflow-x-hidden overflow-y-auto">
          <Outlet />
        </div>
      </div>


    </>
  )
}

export default Landing