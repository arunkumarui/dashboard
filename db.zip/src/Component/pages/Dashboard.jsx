import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { GoGoal } from "react-icons/go";
import { FaHamburger } from "react-icons/fa";
import { IoIosArrowDroprightCircle } from "react-icons/io";
import profile from '../../images/profile1.jpg'
import p2 from '../../images/p-2.png'
import p3 from '../../images/p-3.png'
import p4 from '../../images/p-4.png'
import { FaBasketShopping } from "react-icons/fa6";
import { BsFillBagCheckFill } from "react-icons/bs";
import { BsFillBagXFill } from "react-icons/bs";
import { FaMoneyBillTrendUp } from 'react-icons/fa6';





const Dashboard = () => {


  const orders = [
    { customer: 'Wade Warren', orderNo: '15478256', amount: '$124.00', status: 'Delivered', statusColor: '#175043', image: profile },
    { customer: 'Jane Cooper', orderNo: '48965786', amount: '$365.02', status: 'Delivered', statusColor: '#175043', image: p2 },
    { customer: 'Guy Hawkins', orderNo: '78958215', amount: '$45.88', status: 'Cancelled', statusColor: '#603338', image: p3 },
    { customer: 'Kristin Watson', orderNo: '20965732', amount: '$65.00', status: 'Pending', statusColor: '#603338', image: p4 },
    { customer: 'Cody Fisher', orderNo: '95715620', amount: '$545.00', status: 'Delivered', statusColor: '#175043', image: profile },
    { customer: 'Savannah Nguyen', orderNo: '78514568', amount: '$128.20', status: 'Delivered', statusColor: '#175043', image: profile },
  ];

  // 

  const feedbacks = [
    { name: 'Jenny Wilson', rating: 5, feedback: 'The food was excellent and so was the service. I had the mushroom risotto with scallops which was awesome. I had a burger over greens (gluten-free) which was also very good.', image: profile },
    { name: 'Dianne Russell', rating: 5, feedback: 'We enjoyed the Eggs Benedict served on homemade focaccia bread and hot coffee. Perfect service.', image: p2 },
    { name: 'Devon Lane', rating: 5, feedback: 'Normally wings are wings, but theirs are lean, meaty and tender, and well-seasoned. They are very careful about allergens, and offer a lot of gluten-free options.', image: p3 },
    { name: 'Lane', rating: 5, feedback: 'Normally wings are wings, but theirs are lean, meaty and tender, and well-seasoned. They are very careful about allergens, and offer a lot of gluten-free options.', image: profile },
    { name: 'Roshan Lane', rating: 5, feedback: 'Normally wings are wings, but theirs are lean, meaty and tender, and well-seasoned. They are very careful about allergens, and offer a lot of gluten-free options.', image: profile },
    { name: 'Rohit', rating: 5, feedback: 'Normally wings are wings, but theirs are lean, meaty and tender, and well-seasoned. They are very careful about allergens, and offer a lot of gluten-free options.', image: profile },

  ];

  //   

  const stats = [
    { icon: <FaBasketShopping />, statusColor: '#283468', title: "Total Orders", value: "75", change: 3 },
    { icon: <BsFillBagCheckFill />, statusColor: '#125347', title: "Total Delivered", value: "70", change: -3 },
    { icon: <BsFillBagXFill />, statusColor: '#613239', title: "Total Cancelled", value: "05", change: 3 },
    { icon: <FaMoneyBillTrendUp />, statusColor: '#582848', title: "Total Revenue", value: "$12k", change: -3 },
  ];

  //

  const data = [
    { name: '5', uv: 5000 },
    { name: '9', uv: 10000 },
    { name: '11', uv: 7000 },
    { name: '13', uv: 5000 },
    { name: '15', uv: 6000 },
    { name: '17', uv: 8000 },
    { name: '19', uv: 12000 },
    { name: '21', uv: 15000 },
    { name: '23', uv: 10000 },
    { name: '25', uv: 8000 },
    { name: '27', uv: 6000 },
  ];


  return (
    <>
      <div className="flex flex-wrap mb-4 w-full  h-screen">
        <h3 className='bg-color text-white w-full p-4 text-3xl'>Dashboard</h3>
        <div className="flex flex-wrap w-full p-4 pt-5 bg-color text-white">
          {/* Left section for stats */}
          <div className="w-full md:w-1/2 pr-0 md:pr-2 mb-4 md:mb-0">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {stats.map((stat, index) => (
                <div key={index} className="card-bg-color p-4 rounded">
                  <div style={{ backgroundColor: stat.statusColor }} className="text-3xl mb-1 f-icon">{stat.icon}</div>
                  <p className="text-sm opacity-70">{stat.title}</p>
                  <p className="flex justify-between items-center mt-2">
                    <span className="text-2xl font-bold">{stat.value}</span>
                    <span className={`text-sm ${stat.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {stat.change >= 0 ? '▲' : '▼'} {Math.abs(stat.change)}%
                    </span>
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right section for net profit */}
          <div className="w-full md:w-1/2 pl-0 md:pl-2">
            <div className="card-bg-color p-4 rounded h-full flex justify-between items-start">
              <div>
                <p className="text-sm font-semibold">Net Profit</p>
                <p className="text-3xl font-bold mt-2">$ 6759.25</p>
                <p className="text-green-500 text-sm mt-1">
                  <span className="mr-1">▲</span>3%
                </p>
              </div>
              <div className="relative">
                <svg className="w-24 h-24" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845
          a 15.9155 15.9155 0 0 1 0 31.831
          a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#4B5563"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845
          a 15.9155 15.9155 0 0 1 0 31.831
          a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#3B82F6"
                    strokeWidth="4"
                    strokeDasharray="70, 100"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                  <span className="text-lg font-bold">70%</span>
                  <span className="text-xs circle-chart">Goal<br />Completed</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/*   */}

        <div className="flex flex-col lg:flex-row gap-4 w-full p-4 bg-color text-white">
          <div className="w-full lg:w-2/3 card-bg-color p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Activity</h2>
              <button className="bg-gray-700 px-3 py-1 rounded-full text-sm">Weekly</button>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={data} barGap={4}> {/* Adjust this value as needed */}
                <XAxis dataKey="name" stroke="#ddd" />
                <YAxis stroke="#ddd" />
                <Tooltip cursor={{ fill: 'transparent' }} />
                <Bar dataKey="uv" fill="#6366F1" barSize={40} />
              </BarChart>
            </ResponsiveContainer>

          </div>

          <div className="w-full lg:w-1/3 flex flex-col ">
            <div className="flex items-center card-bg-color p-4 h-100	rounded-tl-md	rounded-tr-md	">
              <div className="bg-red-600 w-14 h-14	 rounded-full flex items-center justify-center">
                <span className="material-icons"><GoGoal /></span>
              </div>
              <p className="ml-4 flex-grow">Goals</p>
              <span className="material-icons">
                <IoIosArrowDroprightCircle className='text-2xl' />
              </span>
            </div>
            <div className="flex items-center card-bg-color p-4 h-100	">
              <div className="bg-blue-600 w-14 h-14	 rounded-full flex items-center justify-center">
                <span className="material-icons"><FaHamburger /></span>
              </div>
              <p className="ml-4 flex-grow">Popular Dishes</p>
              <span className="material-icons">
                <IoIosArrowDroprightCircle className='text-2xl' />
              </span>
            </div>
            <div className="flex items-center card-bg-color p-4 h-100 rounded-bl-md rounded-br-md	">
              <div className="bg-teal-600 w-14 h-14	 rounded-full flex items-center justify-center">
                <span className="material-icons">icon</span>
              </div>
              <p className="ml-4 flex-grow">Menus</p>
              <span className="material-icons"><IoIosArrowDroprightCircle className='text-2xl' />
              </span>
            </div>
          </div>
        </div>


        {/*  */}


        <div className="flex flex-col lg:flex-row gap-4 w-full p-4 bg-color text-white">
          {/* Recent Orders Section */}
          <div className="w-full lg:w-2/3 card-bg-color p-4 rounded-lg">
            <h2 className="text-lg font-semibold mb-4">Recent Orders</h2>
            <table className="w-full text-left">
              <thead>
                <tr>
                  <th className="pb-2">Customer</th>
                  <th className="pb-2">Order No.</th>
                  <th className="pb-2">Amount</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => (
                  <tr key={index} className="text-sm border-t border-gray-700">
                    <td className="py-2 flex items-center">
                      <img src={order.image} alt="Profile" className="w-8 h-8 rounded-full mr-3" />
                      {order.customer}
                    </td>
                    <td className="py-2 text-sm	">{order.orderNo}</td>
                    <td className="py-2 text-sm	">{order.amount}</td>
                    <td className="py-2">
                      <span
                        className="font-semibold table-status w-auto flex items-center px-2 py-1 rounded-full text-white"
                        style={{ backgroundColor: order.statusColor }}
                      >
                        {order.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Customer's Feedback Section */}
          <div className="w-full lg:w-1/3 card-bg-color p-4 rounded-lg">
            <h2 className="text-lg font-semibold mb-4">Customer's Feedback</h2>
            <div className="overflow-y-auto max-h-[330px] custom-scrollbar">
              {feedbacks.map((feedback, index) => (
                <div key={index} className="card-bg-color p-3 border-b border-gray-700">
                  <div className="flex items-center">
                    <img src={feedback.image} alt="Profile" className="w-8 h-8 rounded-full mr-3" />
                    <div>
                      <p className="font-semibold">{feedback.name}</p>
                      <div className="flex">
                        {Array(feedback.rating)
                          .fill()
                          .map((_, i) => (
                            <span key={i} className="text-yellow-500 text-lg">★</span>
                          ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-400 text-sm mb-1">{feedback.feedback}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>


    </>
  );
}

export default Dashboard;
