import React from 'react';
import { Link } from 'react-router-dom'; // Use Link for client-side navigation
import { AiFillHome } from "react-icons/ai";
import { BiBarChartSquare } from "react-icons/bi";
import { CiWallet } from "react-icons/ci";



const Sidebar = ({ sidebaropen }) => {

    const store = [
        {
            title: 'Dashboard',
            icon: <AiFillHome className='text-2xl mr-2' />,
            link: "/",
        },
        {
            title: 'Chart',
            icon: <BiBarChartSquare className='text-2xl mr-2' />,
            link: "/chart",
        },
        {
            title: 'Wallet',
            icon: <CiWallet className='text-2xl mr-2' />,
            link: "/wallet",
        },
    ];

    return (
        <div className={`fixed top-10 left-0 z-40 w-64 h-screen bg-white border-gray-200 sm:translate-x-0 dark:bg-gray-800
            dark:border-gray-700 transition-transform ${sidebaropen ? "translate-x-0" : "-translate-x-full"}`}>
            <div className='h-full px-3 pb-4 overflow-y-auto sidebar-sec'>
                <ul className='space-y-2 mt-6'>
                    {store.map((item, index) => (
                        <li key={index}>
                            <Link to={item.link} className='block text-white  dark:hover:bg-gray-700 p-2 rounded'>
                                <h3 className='flex items-center'>{item.icon}{item.title}</h3>
                            </Link>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

export default Sidebar;
